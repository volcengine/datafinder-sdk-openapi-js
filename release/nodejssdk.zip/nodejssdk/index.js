const { RangersClient } = require('./client');
const dsl = require('./dsl');

module.exports ={
    ...dsl,
    RangersClient,
}